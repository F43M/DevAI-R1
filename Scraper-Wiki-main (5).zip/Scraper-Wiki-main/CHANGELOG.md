# Changelog

All notable changes to this project will be documented in this file.

## [0.1.0] - 2024-06-13
### Added
- Initial release.
