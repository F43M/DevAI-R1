"""Scraping utilities."""

from scraper_wiki import WikipediaAdvanced

__all__ = ["WikipediaAdvanced"]
