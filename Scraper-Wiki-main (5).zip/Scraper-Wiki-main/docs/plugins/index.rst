Plugin Examples
===============

.. toctree::
   :maxdepth: 1

   api_docs
   bitbucket_scraper
   bug_history_scraper
   bugzilla_scraper
   cloud_executor
   code_extractor
   codeforces
   codepen_scraper
   competitions
   cran_packages
   devdocs
   gist_scraper
   github_scraper
   gitlab_scraper
   gitlab_snippets
   hackerrank
   infobox_parser
   jira_scraper
   kaggle
   leetcode
   legacy_forums
   mdn_docs
   notebooks
   npm_packages
   pdf_books
   pip_packages
   rfc_scraper
   sourceforge_scraper
   stackexchange
   stackoverflow
   table_parser
   university_courses
   wikidata
   wikipedia
